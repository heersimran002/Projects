import "./ExpenseList.css";
const ExpenseList = (props) => {};
export default ExpenseList;
